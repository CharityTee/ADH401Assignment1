package authentication;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entities.UsersEntity;
 
@ManagedBean @SessionScoped
public class LoginBean {
	
	@PersistenceContext
	private EntityManager em;
	
    public LoginBean() {
    }
 
    private String userName;
    private String password;
 
    public String getUserName() {
        return userName;
    }
 
    public void setUserName(String userName) {
        this.userName = userName;
    }
 
    public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }
 
    public String validateUserLogin(UsersEntity users) {
        String result = "";
        System.out.println("Entered Username is= " + userName + ", password is= " + password);
        if (userName.equalsIgnoreCase(users.getUsername()) && password.equals(users.getPassword())) {
        	result = "success";
        } else {
        	result = "failure";
        }
        return result;
    }
    
	
    
    public void addNewUsers(UsersEntity users)
    {
    	em.persist(users);
    }
    
}