package controller;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import authentication.LoginBean;
import model.Users;

@ManagedBean(name = "userscontroller")
@SessionScoped
public class UsersController{
 
    @EJB
    private LoginBean loginBean;
    
  //from form
  	@ManagedProperty(value="#{users}")
    private Users usersModel;
 
   
    public String addNewUsers() {
    	loginBean.addNewUsers(usersModel.getEntity());
        return "usersPage.xhtml";
    }
    
    public String validateLogin(){
    	return loginBean.validateUserLogin(usersModel.getEntity());
    }

	public Users getUsers() {
		return usersModel;
	}

	public void setUsers(Users users) {
		this.usersModel = users;
	}
    
    
}